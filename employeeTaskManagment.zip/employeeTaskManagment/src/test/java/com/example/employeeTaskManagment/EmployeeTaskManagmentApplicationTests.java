package com.example.employeeTaskManagment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeeTaskManagmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
