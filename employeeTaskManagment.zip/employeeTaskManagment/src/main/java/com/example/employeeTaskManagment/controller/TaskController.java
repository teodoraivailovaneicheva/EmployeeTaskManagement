package com.example.employeeTaskManagment.controller;

import com.example.employeeTaskManagment.entity.Task;
import com.example.employeeTaskManagment.service.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/task")
public class TaskController {

    @Autowired
    private TaskService taskService;

    //Add new task
    @PostMapping("/addTask")
    public Task addTask(@RequestBody Task task){
        return taskService.addTask(task);
    }

    //Add more than 1 tasks
    @PostMapping("/addTasks")
    public List<Task> addAllTasks(@RequestBody List<Task> tasks){
        return taskService.addAllTasks(tasks);
    }

    //Get task by id
    @GetMapping("/getTaskById/{id}")
    public Task getTaskById(@PathVariable int id){
        return taskService.getTaskById(id);
    }

    //Get task by title
    @GetMapping("/getTaskByName/{title}")
    public Task getTaskByTitle(@PathVariable String title){
        return taskService.getTaskByTitle(title);
    }

    //Update task
    @PutMapping("/updateTask")
    public Task updateTask(@RequestBody Task task){
        return taskService.updateTask(task);
    }

    //Delete task
    @DeleteMapping("/deleteTaskById/{id}")
    public boolean deleteTaskById(@PathVariable int id){
        return taskService.deleteTaskById(id);
    }
}
