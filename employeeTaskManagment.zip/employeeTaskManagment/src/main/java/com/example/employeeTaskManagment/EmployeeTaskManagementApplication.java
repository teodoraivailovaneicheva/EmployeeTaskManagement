package com.example.employeeTaskManagment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployeeTaskManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeTaskManagementApplication.class, args);
	}

}
