package com.example.employeeTaskManagment.service;

import com.example.employeeTaskManagment.entity.Task;
import com.example.employeeTaskManagment.repository.TaskRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class TaskService {

    @Autowired
    private TaskRepository  taskRepository;

    public Task addTask(Task task) {
        return taskRepository.save(task);
    }

    public List<Task> addAllTasks(List<Task> tasks) {
        return taskRepository.saveAll(tasks);
    }

    public Task getTaskById(int id) {
        return taskRepository.findById(id).orElse(null);
    }

    public Task getTaskByTitle(String title) {
        return taskRepository.findByTitle(title);
    }


    public Task updateTask(Task task) {
        Task exTask = taskRepository.findById(task.getId()).orElse(null);
        if(exTask == null){
            return taskRepository.save(task);
        }else{
            taskRepository.deleteById(exTask.getId());
            taskRepository.save(task);
        }
        return task;
    }

    public boolean deleteTaskById(int id) {
        Task exTask = taskRepository.getById(id);
        if(exTask != null){
            taskRepository.deleteById(id);
            return true;
        }
        return false;
    }
}
